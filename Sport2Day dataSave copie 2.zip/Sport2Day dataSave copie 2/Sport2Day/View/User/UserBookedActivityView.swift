import SwiftUI

struct UserBookedActivityView: View {
    
    var body: some View {
        
        VStack {
            Text("UserBookedActivityView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserBookedActivityView_Previews: PreviewProvider {
    static var previews: some View {
        UserBookedActivityView()
    }
}
