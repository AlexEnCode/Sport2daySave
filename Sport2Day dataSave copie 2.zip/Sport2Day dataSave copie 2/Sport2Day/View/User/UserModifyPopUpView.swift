import SwiftUI

struct UserModifyPopUpView: View {
    
    var body: some View {
        
        VStack {
            Text("UserModifyPopUpView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserModifyPopUpView_Previews: PreviewProvider {
    static var previews: some View {
        UserModifyPopUpView()
    }
}
