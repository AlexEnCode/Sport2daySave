import SwiftUI

struct UserDoneView: View {
    
    var body: some View {
        
        VStack {
            Text("UserDoneView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserDoneView_Previews: PreviewProvider {
    static var previews: some View {
        UserDoneView()
    }
}
