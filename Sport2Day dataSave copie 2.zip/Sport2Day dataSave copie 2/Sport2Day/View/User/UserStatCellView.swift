import SwiftUI

struct UserStatCellView: View {
    
    var body: some View {
        
        VStack {
            Text("UserStatCellView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserStatCellView_Previews: PreviewProvider {
    static var previews: some View {
        UserStatCellView()
    }
}
