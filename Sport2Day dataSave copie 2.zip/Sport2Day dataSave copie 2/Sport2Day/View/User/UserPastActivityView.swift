import SwiftUI

struct UserPastActivityView: View {
    
    var body: some View {
        
        VStack {
            Text("UserPastActivityView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserPastActivityView_Previews: PreviewProvider {
    static var previews: some View {
        UserPastActivityView()
    }
}
