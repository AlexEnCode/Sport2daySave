import SwiftUI

struct UserModifyView: View {
    
    var body: some View {
        
        VStack {
            Text("UserModifyView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserModifyView_Previews: PreviewProvider {
    static var previews: some View {
        UserModifyView()
    }
}
