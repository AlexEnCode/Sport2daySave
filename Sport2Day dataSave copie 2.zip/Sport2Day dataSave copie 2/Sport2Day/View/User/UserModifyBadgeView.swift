import SwiftUI

struct UserModifyBadgeView: View {
    
    var body: some View {
        
        VStack {
            Text("UserModifyBadgeView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserModifyBadgeView_Previews: PreviewProvider {
    static var previews: some View {
        UserModifyBadgeView()
    }
}
