import SwiftUI

struct UserActivityDataView: View {
    
    var body: some View {
        
        VStack {
            Text("UserActivityDataView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserActivityDataView_Previews: PreviewProvider {
    static var previews: some View {
        UserActivityDataView()
    }
}
