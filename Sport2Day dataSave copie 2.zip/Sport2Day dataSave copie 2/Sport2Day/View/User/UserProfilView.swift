import SwiftUI

struct UserProfilView: View {
    
    var body: some View {
        
        VStack {
            Text("UserProfilView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserProfilView_Previews: PreviewProvider {
    static var previews: some View {
        UserProfilView()
    }
}
