import SwiftUI

struct UserBadgeView: View {
    
    var body: some View {
        
        VStack {
            Text("UserBadgeView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct UserBadgeView_Previews: PreviewProvider {
    static var previews: some View {
        UserBadgeView()
    }
}
