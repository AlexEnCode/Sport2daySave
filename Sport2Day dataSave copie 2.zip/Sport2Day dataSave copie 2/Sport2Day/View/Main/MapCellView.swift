
// [Alex] 29/10  récupération de mes tests mapKit
// la map s'affiche et permet des annotations
// [Alex] 30/10 mise a jour global taille / Pin / 
// MapCellView.swift

// MapCellView.swift
import SwiftUI
import MapKit
import SwiftData


struct MapCellView: View {
    @Binding var position: MapCameraPosition
    let activities: [Activity]
    @Binding var selectedActivity: Activity?

    @State private var coordinatesCache: [UUID: CLLocationCoordinate2D] = [:]
    @State private var isLoading = false

    private var isPreview: Bool {
        ProcessInfo.processInfo.environment["XCODE_RUNNING_FOR_PREVIEWS"] == "1"
    }

    var body: some View {
        ZStack {
            // Fond stylisé
            RoundedRectangle(cornerRadius: 24)
                .fill(Color.containerGray)
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(Color.black.opacity(0.3), lineWidth: 2)
                )
                .shadow(color: .black.opacity(0.5), radius: 12)
                .padding(.horizontal, 16)

            // Nouvelle API Map
            Map(position: $position) {
                ForEach(activities) { activity in
                    annotationView(for: activity)
                }
            }
            .mapStyle(.standard(elevation: .realistic))
            .cornerRadius(22)
            .clipped()
            .padding(.horizontal, 8)
            .padding(.vertical, 4)

            // Dégradé
            LinearGradient(
                colors: [.clear, .black.opacity(1)],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(height: 120)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            .allowsHitTesting(false)

            // Chargement
            if isLoading {
                ProgressView("Géolocalisation...")
                    .font(.headline.bold())
                    .foregroundColor(.white)
                    .padding(32)
                    .background(.ultraThinMaterial)
                    .cornerRadius(20)
            }
        }
        .task { await loadCoordinates() }
        .onChange(of: activities) { _ in Task { await loadCoordinates() } }
    }

    // MARK: - Annotation builder (fix du problème de compilation)
    @MapContentBuilder
    private func annotationView(for activity: Activity) -> some MapContent {
        if let coord = coordinatesCache[activity.activityID] {
            Annotation(activity.activityTitle, coordinate: coord) {
                Button {
                    selectedActivity = activity
                } label: {
                    CustomActivityPinView(
                        iconName: activity.sport.icon,
                        count: "\(activity.activityPlayers)",
                        color: activity.level.color
                    )
                }
            }
        }
    }

    // MARK: - Chargement asynchrone des coordonnées
    private func loadCoordinates() async {
        guard !activities.isEmpty else {
            await MainActor.run {
                coordinatesCache = [:]
                isLoading = false
            }
            return
        }

        await MainActor.run { isLoading = true }
        var newCache: [UUID: CLLocationCoordinate2D] = [:]

        for (index, activity) in activities.enumerated() {
            if isPreview {
                newCache[activity.activityID] = CLLocationCoordinate2D(
                    latitude: 50.6292 + Double(index) * 0.002,
                    longitude: 3.0573 + Double(index) * 0.002
                )
            } else if let coord = await activity.coordinates() {
                newCache[activity.activityID] = coord
            } else {
                newCache[activity.activityID] = CLLocationCoordinate2D(latitude: 50.6333, longitude: 3.0667)
            }
        }

        await MainActor.run {
            coordinatesCache = newCache
            isLoading = false
        }
    }
}


    
    // Choix des icônes, à supprimer ?
    private func sportIcon(for sport: String) -> String {
        switch sport.lowercased() {
        case "basketball": return "basketball.fill"
        case "tennis": return "tennisball.fill"
        case "Musculation": return "dumbbell.fill"
        case "football": return "soccerball"
        case "course à pied": return "figure.run"
        case "volley": return "volleyball.fill"
        case "Rugby": return "rugbyball.fill"
        case "Skateboard": return "skateboard.fill"
        case "Randonnée": return "figure.hiking"
        default: return "questionmark.circle"
        }
    }

