//
//  SearchFilterPopUpView.swift
//  Sport2Day
//
//  Created by apprenant74 on 31/10/2025.
//

import SwiftUI

struct SearchFilterPopUpView: View {
    @Binding var searchText: String
    @Environment(\.dismiss) private var dismiss
    var onApply: (SearchFilters) -> Void
    
    @State private var tempSearchText: String
    @State private var selectedSports: Set<SportType> = []
    @State private var selectedLevel: LevelType = .all
    @State private var participantValue: Double = 8
    @State private var dateStart: Date = Date()
    @State private var dateEnd: Date = Date().addingTimeInterval(86400 * 7)
    @State private var selectedAccessibility: Set<String> = []
    
    private let sports = [
        ("basketball.fill", "Basketball"),
        ("tennisball.fill", "Tennis"),
        ("dumbbell.fill", "Musculation"),
        ("volleyball.fill", "Volley-ball"),
        ("soccerball", "Football"),
        ("figure.run", "Course à pied"),
        ("figure.hiking", "Randonnée"),
        ("rugbyball.fill", "Rugby"),
        ("skateboard.fill", "Skateboard"),
        ("questionmark.circle", "Autre")
    ]
    
    private let levelColors: [LevelType: Color] = [
        .novice: Color("noviceGreen"),
        .inter: Color("interPurple"),
        .pro: Color("proBlue"),
        .all: Color("allYellow")
    ]
    
    init(searchText: Binding<String>, onApply: @escaping (SearchFilters) -> Void) {
        self._searchText = searchText
        self.onApply = onApply
        self._tempSearchText = State(initialValue: searchText.wrappedValue)
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    // Recherche
                    HStack {
                        Image(systemName: "magnifyingglass").foregroundColor(.white)
                        TextField("Ville", text: $tempSearchText)
                            .foregroundColor(.white)
                            .submitLabel(.search)
                            .onSubmit { applyFilters() }
                    }
                    .padding()
                    .background(Color.containerGray)
                    .cornerRadius(14)
                    
                    // Sports
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Sports").foregroundColor(.white).fontWeight(.semibold)
                        LazyVGrid(columns: Array(repeating: .init(.flexible(), spacing: 12), count: 5), spacing: 12) {
                            ForEach(sports, id: \.1) { icon, name in
                                SportButton(
                                    icon: icon,
                                    title: name,
                                    isSelected: selectedSports.contains { $0.rawValue == name }
                                ) {
                                    if let sport = SportType(rawValue: name) {
                                        toggle(&selectedSports, sport)
                                    }
                                }
                            }
                        }
                        .frame(maxHeight: 140)
                    }
                    
                    // Niveau
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Niveau").foregroundColor(.white).fontWeight(.semibold)
                        HStack(spacing: 14) {
                            ForEach(LevelType.allCases) { level in
                                LevelButton(
                                    title: level.displayName,
                                    color: levelColors[level] ?? .gray,
                                    isSelected: selectedLevel == level
                                ) {
                                    selectedLevel = level
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                    }
                    
                    // Accessibilités
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Accessibilités").foregroundColor(.white).fontWeight(.semibold)
                        LazyVGrid(columns: Array(repeating: .init(.flexible(), spacing: 12), count: 4), spacing: 12) {
                            ForEach(["HANDICAP", "FEMMES", "HOMMES", "QUEERS"], id: \.self) { option in
                                AccessibilityButton(
                                    option: option,
                                    isSelected: selectedAccessibility.contains(option)
                                ) {
                                    toggle(&selectedAccessibility, option)
                                }
                            }
                        }
                    }
                    
                    // Dates
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Période").foregroundColor(.white).fontWeight(.bold)
                        HStack(spacing: 0) {
                            DatePicker("Du", selection: $dateStart, in: Date()..., displayedComponents: .date)
                                .labelsHidden()
                                .datePickerStyle(.compact)
                                .colorScheme(.dark)
                                .padding(.horizontal, 12)
                                .frame(maxWidth: .infinity)
                            
                            Text(":").foregroundColor(.white.opacity(0.7)).fontWeight(.semibold).padding(.horizontal, 8)
                            
                            DatePicker("Au", selection: $dateEnd, in: dateStart..., displayedComponents: .date)
                                .labelsHidden()
                                .datePickerStyle(.compact)
                                .colorScheme(.dark)
                                .padding(.horizontal, 12)
                                .frame(maxWidth: .infinity)
                        }
                        .frame(height: 52)
                        .background(Color.containerGray)
                        .cornerRadius(8)
                    }
                    .padding(.top, 12)
                    
                    // Participants
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Participants").foregroundColor(.white).fontWeight(.semibold)
                            Spacer()
                            Text("\(Int(participantValue))").foregroundColor(.white).font(.caption)
                        }
                        Slider(value: $participantValue, in: 1...15, step: 1).tint(.orangePrimary)
                    }
                    
                    // Bouton
                    Button("Rechercher") {
                        applyFilters()
                    }
                    .font(.title3.bold())
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(Color.orangePrimary)
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.3), radius: 6)
                }
                .padding()
            }
            .background(Color.bluePrimary.ignoresSafeArea())
        }
    }
    
    private func applyFilters() {
        searchText = tempSearchText
        let filters = SearchFilters(
            searchText: tempSearchText,
            sports: Set(selectedSports.map { $0.rawValue }),
            level: selectedLevel.rawValue,
            accessibility: selectedAccessibility,
            participantsMin: Int(participantValue),
            participantsMax: 15,
            dateStart: dateStart,
            dateEnd: dateEnd
        )
        onApply(filters)
        dismiss()
    }
    
    private func toggle<T: Hashable>(_ set: inout Set<T>, _ value: T) {
        if set.contains(value) {
            set.remove(value)
        } else {
            set.insert(value)
        }
    }
}

// MARK: - SearchFilters
struct SearchFilters {
    var searchText: String
    var sports: Set<String>
    var level: String
    var accessibility: Set<String>
    var participantsMin: Int
    var participantsMax: Int
    var dateStart: Date?
    var dateEnd: Date?
    
    init(
        searchText: String = "",
        sports: Set<String> = [],
        level: String = "TOUS",
        accessibility: Set<String> = [],
        participantsMin: Int = 1,
        participantsMax: Int = 15,
        dateStart: Date? = nil,
        dateEnd: Date? = nil
    ) {
        self.searchText = searchText
        self.sports = sports
        self.level = level
        self.accessibility = accessibility
        self.participantsMin = participantsMin
        self.participantsMax = participantsMax
        self.dateStart = dateStart
        self.dateEnd = dateEnd
    }
    
    static var empty: SearchFilters { SearchFilters() }
}




private let levelColors: [LevelType: Color] = [
    .novice: Color("noviceGreen"),
    .inter: Color("interPurple"),
    .pro: Color("proBlue"),
    .all: Color("allYellow")
]
