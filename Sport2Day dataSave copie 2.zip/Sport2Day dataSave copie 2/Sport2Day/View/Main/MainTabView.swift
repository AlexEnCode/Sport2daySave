import SwiftUI
import SwiftData



struct MainTabView: View {
    @Query(sort: \Activity.activityDate, order: .reverse) private var activities: [Activity]

    var body: some View {
        TabView {
            MapView()
                .tabItem { Label("Carte", systemImage: "mappin.circle.fill") }
            
     //       ActivityListCellView()
            MapView()
                .tabItem { Label("Activités", systemImage: "book.fill") }
            
      //      ErikaProfileView()
            MapView()
                .tabItem { Label("Profil", systemImage: "person.crop.circle") }
        }
        .tint(.orangePrimary)
    }
}



/*
// MARK: - Seed Data
private func seedData(in container: ModelContainer) async {
    let context = container.mainContext
    
    // Évite de dupliquer
    if try! context.fetch(FetchDescriptor<Activity>()).isEmpty {
        context.insert(erika)
        context.insert(julie)
        context.insert(alex)
        
        for activity in activities {
            context.insert(activity)
        }
        
        try? context.save()
    }
}

// MARK: - Preview
#Preview {
    let container = try! ModelContainer(
        for: [User.self, Activity.self],
        configurations: .init(isStoredInMemoryOnly: true)
    )
    
    // Insère TOUTES les données dans la preview
    let context = container.mainContext
    context.insert(erika)
    context.insert(julie)
    context.insert(alex)
    for activity in activities {
        context.insert(activity)
    }
    try? context.save()
    
    return MainTabView()
        .modelContainer(container)
}


 */
