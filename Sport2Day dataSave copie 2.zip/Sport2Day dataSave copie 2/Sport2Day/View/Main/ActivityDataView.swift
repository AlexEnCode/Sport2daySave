import SwiftUI

struct ActivityDataView: View {
    
    var body: some View {
        
        VStack {
            Text("ActivityDataView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct ActivityDataView_Previews: PreviewProvider {
    static var previews: some View {
        ActivityDataView()
    }
}
