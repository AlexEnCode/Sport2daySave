
// [Alex] 29/10  récupération de mes tests mapKit
// Ajout des Cell
// SearchCellView fonctionnel uniquement pour l'adresse
// Map début
// La bar de recherche n'est pas encré
//[Alex] 03/11 Tout les élléménets sont fonctinelle, ajout du bouton creatActivity
// [Alex] 04/11 bouton create activity fonctionnelle



import SwiftUI
import MapKit
import SwiftData

struct MapView: View {
    // MARK: - Environment & Données
    @Environment(\.modelContext) private var context
    @Query(sort: \Activity.activityDate) private var activities: [Activity]

    // MARK: - États
    @State private var selectedActivity: Activity?
    @State private var position: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 50.6292, longitude: 3.0573),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
    )

    @State private var showActivityPopup = false
    @State private var showFilterPopup = false
    @State private var showListView = false
    @State private var showCreateActivity = false

    @State private var searchText = ""
    @State private var filters = SearchFilters.empty

    @Namespace private var animation

    // MARK: - Corps principal
    var body: some View {
        ZStack {
            // --- Fond principal ---
            Color("bluePrimary")
                .ignoresSafeArea()

            VStack(spacing: 12) {
                // --- Barre supérieure (recherche + switch carte/liste) ---
                VStack(spacing: 8) {
                    // Faux champ de recherche
                    Button {
                        showFilterPopup = true
                    } label: {
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.white.opacity(0.9))
                            Text("Rechercher une activité")
                                .foregroundColor(.white.opacity(0.9))
                                .font(.subheadline)
                            Spacer()
                        }
                        .padding(.horizontal)
                        .frame(height: 42)
                        .background(Color("containerGray"))
                        .cornerRadius(10)
                    }

                    // Switch Carte / Liste
                    ZStack {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color("containerGray"))

                        HStack(spacing: 0) {
                            Button {
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    showListView = false
                                }
                            } label: {
                                Text("Carte")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 36)
                                    .background(
                                        Group {
                                            if !showListView {
                                                RoundedRectangle(cornerRadius: 8)
                                                    .fill(Color.orangePrimary)
                                                    .matchedGeometryEffect(id: "tab", in: animation)
                                            }
                                        }
                                    )
                                    .foregroundColor(!showListView ? .white : .white.opacity(0.7))
                            }

                            Button {
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    showListView = true
                                }
                            } label: {
                                Text("Liste")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 36)
                                    .background(
                                        Group {
                                            if showListView {
                                                RoundedRectangle(cornerRadius: 8)
                                                    .fill(Color.orangePrimary)
                                                    .matchedGeometryEffect(id: "tab", in: animation)
                                            }
                                        }
                                    )
                                    .foregroundColor(showListView ? .white : .white.opacity(0.7))
                            }
                        }
                        .padding(4)
                    }
                    .frame(height: 44)
                    .animation(.easeInOut(duration: 0.25), value: showListView)
                }
                .padding(.top, 30)
                .padding(.horizontal, 16)

                // --- Carte ou Liste ---
                if showListView {
                    ActivityListCellView(activities: filteredActivities)
                        .transition(.opacity.combined(with: .scale))
                        .padding(.horizontal, 8)
                        .padding(.bottom, 16)
                } else {
                    MapCellView(
                        position: $position,
                        activities: filteredActivities,
                        selectedActivity: $selectedActivity
                    )
                    .frame(maxWidth: .infinity)
                    .frame(maxHeight: .infinity)
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .transition(.opacity)
                }
            }

            // --- Dégradé sombre en bas ---
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.black.opacity(0.0),
                    Color.black.opacity(0.3),
                    Color.black.opacity(0.7)
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            // --- Bouton flottant (+) ---
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button {
                        showCreateActivity = true
                    } label: {
                        Image(systemName: "plus")
                            .font(.title2.weight(.bold))
                            .foregroundColor(.orangePrimary)
                            .padding(20)
                            .background(
                                Circle()
                                    .fill(Color.white.opacity(0.8))
                                    .overlay(
                                        Circle()
                                            .stroke(Color.orangePrimary.opacity(0.9), lineWidth: 1)
                                    )
                            )
                            .shadow(color: .black.opacity(0.25), radius: 4, y: 2)
                    }
                    .padding(.trailing, 22)
                    .padding(.bottom, 32)
                }
            }

            // --- Popup Activité ---
            if showActivityPopup, let selected = selectedActivity {
                VStack {
                    Spacer()
                    ActivityInfoPopUpCellView(activity: selected) {
                        withAnimation(.spring()) {
                            showActivityPopup = false
                            selectedActivity = nil
                        }
                    }
                    .padding(.horizontal, 12)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }

        // --- Popup Filtres ---
        .sheet(isPresented: $showFilterPopup) {
            SearchFilterPopUpView(searchText: $searchText) { newFilters in
                filters = newFilters
            }
        }

        // --- Vue de création d’activité ---
        .sheet(isPresented: $showCreateActivity) {
            CreateActivityView()
        }
    }

    // MARK: - Filtrage
    private var filteredActivities: [Activity] {
        activities.filter { activity in
            var matches = true

            if !filters.searchText.isEmpty {
                matches = activity.activityLocation.localizedCaseInsensitiveContains(filters.searchText)
                || activity.sport.rawValue.localizedCaseInsensitiveContains(filters.searchText)
            }

            if !filters.sports.isEmpty {
                matches = matches && filters.sports.contains(activity.sport.rawValue)
            }

            if filters.level != "TOUS" {
                matches = matches && activity.level.rawValue == filters.level
            }

            matches = matches && activity.activityPlayers >= filters.participantsMin
            && activity.activityPlayers <= filters.participantsMax

            if let start = filters.dateStart, let end = filters.dateEnd {
                matches = matches && (activity.activityDate >= start && activity.activityDate <= end)
            }

            return matches
        }
    }
}

// MARK: - Coins arrondis spécifiques
fileprivate extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

fileprivate struct RoundedCorner: Shape {
    var radius: CGFloat
    var corners: UIRectCorner
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}


