import SwiftUI

struct LoginView: View {
    
    var body: some View {
        
        VStack {
            Text("LoginView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
