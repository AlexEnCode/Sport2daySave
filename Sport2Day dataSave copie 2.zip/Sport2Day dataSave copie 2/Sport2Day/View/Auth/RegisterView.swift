import SwiftUI

struct RegisterView: View {
    
    var body: some View {
        
        VStack {
            Text("RegisterView")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}
