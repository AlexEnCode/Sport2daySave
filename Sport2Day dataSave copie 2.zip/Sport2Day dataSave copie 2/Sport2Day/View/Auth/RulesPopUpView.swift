// [Emilie] Test

import SwiftUI

struct RulesPopUpView: View {
    
var body: some View{
        
        ZStack {
            
            Color(.black)
                .ignoresSafeArea()
            
            RoundedRectangle(cornerRadius: 16)
                .foregroundColor(.gray)
                .frame(width: 350, height: 700)
            
            VStack{
                
                Text("RÈGLEMENT DE SPORT2DAY")
                    .font(.title2)
                    .foregroundColor(.white)
            }
        }
    }
}

#Preview {
    RulesPopUpView()
}
