import SwiftUI

struct AccessibilityView: View {
    
    var body: some View {
        
        VStack {
            Text("Accessibility View")
                .font(.title)
                .padding()
            
        }
        .padding()
    }
}

struct AccessibilityView_Previews: PreviewProvider {
    static var previews: some View {
        AccessibilityView()
    }
}
